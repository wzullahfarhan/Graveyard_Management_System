package Oparetions;

public interface AddUserOp {
    void adduser(String username,String password,String name,String email);
    
}
