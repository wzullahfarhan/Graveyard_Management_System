package Oparetions;

public interface AddDeathOp {
    void adddeath(String textF1,String textF2,String textF3,String textF4);
    
}
