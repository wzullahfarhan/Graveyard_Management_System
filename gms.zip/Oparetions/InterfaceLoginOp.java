package Oparetions;

public interface InterfaceLoginOp {
    void MatchInAdmin(String TF1,String TF2);
}