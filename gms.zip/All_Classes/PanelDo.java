package All_Classes;

public class PanelDo {
    public PanelDo(){
        
        

    }
    public PanelDo(boolean n){
        new Welcome();

    }
    public PanelDo(boolean a,boolean b){
        new FirstHome();

    }

    public void setVisible(boolean b) {
    }
    
}
