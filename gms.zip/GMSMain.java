import All_Classes.*;

public class GMSMain {
    public static void main(String args[]) {
    new Welcome();
    
  }
    
}
